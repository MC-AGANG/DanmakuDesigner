﻿
''' <summary>
''' 表示一个关卡。
''' </summary>
Public MustInherit Class Stage
    ''' <summary>
    ''' 获取或设置关卡的背景动画。
    ''' </summary>
    Public Background As UserControl
    ''' <summary>
    ''' 获取或设置关卡运行时间
    ''' </summary>
    ''' <returns></returns>
    Public Property Ticks As Long
    ''' <summary>
    ''' 获取或设置关卡难度
    ''' </summary>
    ''' <returns></returns>
    Public Property Difficulty As Difficulty
    ''' <summary>
    ''' 获取或设置关卡标题图片。
    ''' </summary>
    Public Title As ImageBrush
    Private TitleTick As Integer = 0
    Private Shared MusicTick As Integer = 0
    ''' <summary>
    ''' 初始化关卡，继承后必须重写。
    ''' </summary>
    Public MustOverride Sub Initialize()
    ''' <summary>
    ''' 运行这个关卡的主循环。
    ''' </summary>
    Public Overridable Sub Render()
        Action()
        Ticks += 1
        If TitleTick > 0 Then
            TitleTick -= 1
            If TitleTick >= 250 Then
                STG.TitleArea.Opacity = (300 - TitleTick) / 50
            ElseIf TitleTick <= 50 Then
                STG.TitleArea.Opacity = TitleTick / 50
            End If
        End If
        If MusicTick > 0 Then
            MusicTick -= 1
            If MusicTick >= 280 Then
                STG.MusicArea.Margin = New Thickness(0, 0, -(MusicTick - 280) * 8, 0)
            ElseIf MusicTick <= 40 Then
                STG.MusicArea.Margin = New Thickness(0, 0, -(40 - MusicTick) * 8, 0)
            End If
        End If
    End Sub
    ''' <summary>
    ''' 设置关卡脚本，继承后必须重写。
    ''' </summary>
    Public MustOverride Sub Action()
    ''' <summary>
    ''' 创建新的关卡实例。
    ''' </summary>
    ''' <param name="Difficulty">设置关卡难度</param>
    Public Sub New(Difficulty As Difficulty)
        Me.Difficulty = Difficulty
        Initialize()
    End Sub
    Public Sub ShowTitle()
        STG.TitleArea.Fill = Title
        TitleTick = 300
    End Sub
    Public Shared Sub Showmusic(s As String)
        STG.MusicArea.Content = s
        MusicTick = 320
    End Sub
    ''' <summary>
    ''' 加载关卡到游戏中。
    ''' </summary>
    Public Sub Load()
        If Not IsNothing(Background) Then
            STG.BackLayer.Children.Add(Background)
        End If
    End Sub
    ''' <summary>
    ''' 卸载关卡。
    ''' </summary>
    Public Sub Unload()
        If Not IsNothing(Background) Then
            STG.BackLayer.Children.Remove(Background)
        End If
        Reset()
    End Sub
    ''' <summary>
    ''' 重置关卡状态
    ''' </summary>
    Public Overridable Sub Reset()
        Ticks = 0
        If Not IsNothing(Background) AndAlso STG.BackLayer.Children.Contains(Background) Then
            STG.BackLayer.Children.Remove(Background)
        End If
    End Sub
    ''' <summary>
    ''' 通过当前关卡
    ''' </summary>
    Public Overridable Sub Clear()
        Reset()
        STG.NextStage()
    End Sub
End Class
Public Enum Difficulty
    Easy = 1
    Normal = 2
    Hard = 3
    Lunatic = 4
    Override = 5
    Extra = 9
    Phantasm = 10
End Enum