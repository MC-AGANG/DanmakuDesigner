﻿Imports System.Threading
''' <summary>
''' 用于表示媒体定时器
''' 此定时器具有极高的精度
''' 可用于使游戏按一定速率稳定运行
''' </summary>
Public Class MediaTimer
    ''' <summary>
    ''' 到达时间间隔时触发
    ''' </summary>
    ''' <param name="MSPT">这一刻处理完负载耗费的时间，单位：毫秒</param>
    Public Event Tick(MSPT As Double)
    ''' <summary>
    ''' 获取或设置定时器每秒运行多少次<br/>
    ''' 当工作负载超过计算机处理能力时，实际的TPS会下降
    ''' </summary>
    ''' <returns></returns>
    Public Property TPS As Double
    ''' <summary>
    ''' 获取或设置这个定时器的工作负载
    ''' 由于定时器使用异步线程，此方法需要委托
    ''' </summary>
    Public Act As New List(Of Action)
    Private Enabled As Boolean
    Private T As Task
    Private SW As Stopwatch
    ''' <summary>
    ''' 获取最近的一个tick的计算消耗了多久
    ''' </summary>
    Public MSPT As Double
    ''' <summary>
    ''' 创建新的MediaTimer
    ''' </summary>
    ''' <param name="TPS">定时器每秒运行的次数</param>
    ''' <param name="Act">定时器的工作负载，需要委托</param>
    Public Sub New(TPS As Double, Optional Act As Action = Nothing)
        Me.TPS = TPS
        If Not IsNothing(Act) Then
            Me.Act.Add(Act)
        End If

        SW = New Stopwatch
    End Sub
    ''' <summary>
    ''' 启动定时器
    ''' </summary>
    Public Sub Start()
        If Not Enabled Then
            T = New Task(AddressOf Main)
            T.Start()
            Enabled = True
        End If
    End Sub
    ''' <summary>
    ''' 使定时器停止
    ''' </summary>
    Public Sub [Stop]()
        If Enabled Then
            Enabled = False
            T = Nothing
        End If
    End Sub
    Private Sub Main()
        Do While Enabled
            SW.Restart()
            For i = 0 To Act.Count - 1
                Act(i).Invoke
            Next
            RaiseEvent Tick(SW.ElapsedTicks / 10000)
            MSPT = SW.ElapsedTicks / 10000
            If SW.ElapsedTicks < (10000000 / TPS) Then
                Dim sleeptime As Integer = 900 / TPS - SW.ElapsedTicks * (1000 / Stopwatch.Frequency)
                If sleeptime > 0 Then
                    Thread.Sleep(sleeptime)
                End If
                Do Until SW.ElapsedTicks >= (10000000 / TPS)
                    Thread.Sleep(0)
                Loop
            End If
        Loop
        SW.Stop()
    End Sub
    ''' <summary>
    ''' 获取定时器是否处于工作状态
    ''' </summary>
    ''' <returns></returns>
    Public Function IsEnabled() As Boolean
        Return Enabled
    End Function

End Class
